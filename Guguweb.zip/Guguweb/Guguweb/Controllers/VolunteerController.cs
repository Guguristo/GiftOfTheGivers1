using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Guguweb.Models;
using Guguweb.Models.ViewModels;
using System.Security.Claims;

namespace Guguweb.Controllers
{
    [Authorize]
    public class VolunteerController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<VolunteerController> _logger;

        public VolunteerController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            ILogger<VolunteerController> logger)
        {
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }

        // GET: Volunteer/Register
        public async Task<IActionResult> Register()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var existingVolunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (existingVolunteer != null)
            {
                TempData["InfoMessage"] = "You are already registered as a volunteer.";
                return RedirectToAction(nameof(Profile));
            }

            return View();
        }

        // POST: Volunteer/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(VolunteerViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                
                var volunteer = new Volunteer
                {
                    UserId = userId!,
                    Skills = model.Skills,
                    Experience = model.Experience,
                    Availability = model.Availability,
                    EmergencyContact = model.EmergencyContact,
                    EmergencyPhone = model.EmergencyPhone,
                    SkillLevel = (SkillLevel)model.SkillLevel,
                    Status = VolunteerStatus.Active
                };

                _context.Add(volunteer);
                await _context.SaveChangesAsync();
                _logger.LogInformation("User {UserId} registered as volunteer: {VolunteerId}", userId, volunteer.Id);
                
                TempData["SuccessMessage"] = "You have successfully registered as a volunteer! Thank you for your commitment to helping others.";
                return RedirectToAction(nameof(Profile));
            }

            return View(model);
        }

        // GET: Volunteer/Profile
        public async Task<IActionResult> Profile()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var volunteer = await _context.Volunteers
                .Include(v => v.User)
                .Include(v => v.AssignedTasks)
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                return RedirectToAction(nameof(Register));
            }

            var assignments = await _context.VolunteerTaskAssignments
                .Include(vta => vta.Task)
                .Where(vta => vta.VolunteerId == volunteer.Id)
                .ToListAsync();

            var viewModel = new VolunteerViewModel
            {
                Id = volunteer.Id,
                Skills = volunteer.Skills,
                Experience = volunteer.Experience,
                Availability = volunteer.Availability,
                EmergencyContact = volunteer.EmergencyContact,
                EmergencyPhone = volunteer.EmergencyPhone,
                SkillLevel = (int)volunteer.SkillLevel,
                Status = (int)volunteer.Status,
                UserName = $"{volunteer.User.FirstName} {volunteer.User.LastName}",
                UserEmail = volunteer.User.Email,
                DateJoined = volunteer.DateJoined,
                TotalTasks = assignments.Count,
                CompletedTasks = assignments.Count(a => a.Status == AssignmentStatus.Completed),
                TotalHours = assignments.Where(a => a.HoursWorked.HasValue).Sum(a => a.HoursWorked!.Value)
            };

            return View(viewModel);
        }

        // POST: Volunteer/Profile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(VolunteerViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var volunteer = await _context.Volunteers
                    .FirstOrDefaultAsync(v => v.UserId == userId);

                if (volunteer == null)
                {
                    return NotFound();
                }

                volunteer.Skills = model.Skills;
                volunteer.Experience = model.Experience;
                volunteer.Availability = model.Availability;
                volunteer.EmergencyContact = model.EmergencyContact;
                volunteer.EmergencyPhone = model.EmergencyPhone;
                volunteer.SkillLevel = (SkillLevel)model.SkillLevel;
                volunteer.DateUpdated = DateTime.UtcNow;

                _context.Update(volunteer);
                await _context.SaveChangesAsync();
                _logger.LogInformation("User {UserId} updated volunteer profile: {VolunteerId}", userId, volunteer.Id);
                
                TempData["SuccessMessage"] = "Your volunteer profile has been updated successfully.";
                return RedirectToAction(nameof(Profile));
            }

            return View(model);
        }

        // GET: Volunteer/Tasks
        public async Task<IActionResult> Tasks()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                TempData["ErrorMessage"] = "You must be registered as a volunteer to view tasks.";
                return RedirectToAction(nameof(Register));
            }

            var availableTasks = await _context.VolunteerTasks
                .Where(vt => vt.Status == Models.TaskStatus.Open)
                .OrderByDescending(vt => vt.Priority)
                .ThenBy(vt => vt.DateCreated)
                .ToListAsync();

            var myAssignments = await _context.VolunteerTaskAssignments
                .Include(vta => vta.Task)
                .Where(vta => vta.VolunteerId == volunteer.Id)
                .OrderByDescending(vta => vta.AssignedDate)
                .ToListAsync();

            var availableTaskViewModels = availableTasks.Select(vt => new VolunteerTaskViewModel
            {
                Id = vt.Id,
                Title = vt.Title,
                Type = (int)vt.Type,
                Priority = (int)vt.Priority,
                Description = vt.Description,
                Location = vt.Location,
                StartDate = vt.StartDate,
                EndDate = vt.EndDate,
                RequiredVolunteers = vt.RequiredVolunteers,
                RequiredSkills = vt.RequiredSkills,
                Instructions = vt.Instructions,
                Status = (int)vt.Status,
                DateCreated = vt.DateCreated,
                AssignedVolunteers = _context.VolunteerTaskAssignments.Count(vta => vta.TaskId == vt.Id)
            }).ToList();

            var assignmentViewModels = myAssignments.Select(vta => new VolunteerTaskAssignmentViewModel
            {
                Id = vta.Id,
                TaskId = vta.TaskId,
                VolunteerId = vta.VolunteerId,
                Status = (int)vta.Status,
                AssignedDate = vta.AssignedDate,
                AcceptedDate = vta.AcceptedDate,
                StartedDate = vta.StartedDate,
                CompletedDate = vta.CompletedDate,
                VolunteerNotes = vta.VolunteerNotes,
                SupervisorNotes = vta.SupervisorNotes,
                HoursWorked = vta.HoursWorked,
                TaskTitle = vta.Task.Title,
                TaskType = vta.Task.Type.ToString(),
                TaskPriority = vta.Task.Priority.ToString()
            }).ToList();

            ViewBag.AvailableTasks = availableTaskViewModels;
            ViewBag.MyAssignments = assignmentViewModels;

            return View();
        }

        // POST: Volunteer/JoinTask
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> JoinTask(int taskId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                TempData["ErrorMessage"] = "You must be registered as a volunteer to join tasks.";
                return RedirectToAction(nameof(Register));
            }

            var task = await _context.VolunteerTasks
                .FirstOrDefaultAsync(vt => vt.Id == taskId && vt.Status == Models.TaskStatus.Open);

            if (task == null)
            {
                TempData["ErrorMessage"] = "Task not found or no longer available.";
                return RedirectToAction(nameof(Tasks));
            }

            var existingAssignment = await _context.VolunteerTaskAssignments
                .FirstOrDefaultAsync(vta => vta.TaskId == taskId && vta.VolunteerId == volunteer.Id);

            if (existingAssignment != null)
            {
                TempData["ErrorMessage"] = "You are already assigned to this task.";
                return RedirectToAction(nameof(Tasks));
            }

            var assignment = new VolunteerTaskAssignment
            {
                TaskId = taskId,
                VolunteerId = volunteer.Id,
                Status = AssignmentStatus.Assigned
            };

            _context.Add(assignment);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Volunteer {VolunteerId} joined task {TaskId}", volunteer.Id, taskId);
            
            TempData["SuccessMessage"] = "You have successfully joined the task!";
            return RedirectToAction(nameof(Tasks));
        }

        // POST: Volunteer/UpdateAssignmentStatus
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAssignmentStatus(int assignmentId, int status, string? notes = null)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                return Json(new { success = false, message = "Volunteer not found." });
            }

            var assignment = await _context.VolunteerTaskAssignments
                .FirstOrDefaultAsync(vta => vta.Id == assignmentId && vta.VolunteerId == volunteer.Id);

            if (assignment == null)
            {
                return Json(new { success = false, message = "Assignment not found." });
            }

            assignment.Status = (AssignmentStatus)status;
            assignment.VolunteerNotes = notes;

            switch ((AssignmentStatus)status)
            {
                case AssignmentStatus.Accepted:
                    assignment.AcceptedDate = DateTime.UtcNow;
                    break;
                case AssignmentStatus.Started:
                    assignment.StartedDate = DateTime.UtcNow;
                    break;
                case AssignmentStatus.Completed:
                    assignment.CompletedDate = DateTime.UtcNow;
                    break;
            }

            assignment.DateUpdated = DateTime.UtcNow;

            _context.Update(assignment);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Volunteer {VolunteerId} updated assignment {AssignmentId} status to {Status}", volunteer.Id, assignmentId, status);

            return Json(new { success = true, message = "Assignment status updated successfully." });
        }

        private bool VolunteerExists(int id)
        {
            return _context.Volunteers.Any(e => e.Id == id);
        }
    }
}
