using System.Diagnostics;
using Guguweb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Guguweb.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Get some statistics for the home page
            var totalDonations = await _context.Donations.CountAsync();
            var totalOrganizations = await _context.Organizations.Where(o => o.IsActive && o.IsVerified).CountAsync();
            var totalValue = await _context.Donations
                .Where(d => d.EstimatedValue.HasValue)
                .SumAsync(d => d.EstimatedValue!.Value);

            ViewBag.TotalDonations = totalDonations;
            ViewBag.TotalOrganizations = totalOrganizations;
            ViewBag.TotalValue = totalValue;

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
