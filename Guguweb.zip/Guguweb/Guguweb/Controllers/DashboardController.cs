using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Guguweb.Models;
using Guguweb.Models.ViewModels;
using System.Security.Claims;

namespace Guguweb.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<DashboardController> _logger;

        public DashboardController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            ILogger<DashboardController> logger)
        {
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = await _userManager.FindByIdAsync(userId!);

            if (user == null)
            {
                return NotFound();
            }

            // Get user's donations
            var donations = await _context.Donations
                .Include(d => d.Organization)
                .Where(d => d.UserId == userId)
                .OrderByDescending(d => d.DateDonated)
                .ToListAsync();

            // Get recent donations (last 5)
            var recentDonations = donations.Take(5).Select(d => new DonationViewModel
            {
                Id = d.Id,
                Type = (int)d.Type,
                Item = d.Item,
                Quantity = d.Quantity,
                EstimatedValue = d.EstimatedValue,
                Notes = d.Notes,
                DateDonated = d.DateDonated,
                OrganizationId = d.OrganizationId,
                OrganizationName = d.Organization?.Name,
                DeliveryAddress = d.DeliveryAddress,
                DeliveryInstructions = d.DeliveryInstructions,
                DeliveryDate = d.DeliveryDate,
                Status = (int)d.Status
            }).ToList();

            // Calculate statistics
            var donationTypeStats = donations
                .GroupBy(d => d.Type.ToString())
                .ToDictionary(g => g.Key, g => g.Count());

            var monthlyDonations = donations
                .Where(d => d.EstimatedValue.HasValue)
                .GroupBy(d => d.DateDonated.ToString("yyyy-MM"))
                .ToDictionary(g => g.Key, g => g.Sum(d => d.EstimatedValue!.Value));

            // Create view models
            var userProfile = new UserProfileViewModel
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email!,
                PhoneNumber = user.PhoneNumber,
                Address = user.Address,
                City = user.City,
                State = user.State,
                ZipCode = user.ZipCode,
                DateJoined = user.DateJoined,
                TotalDonations = donations.Count,
                TotalValueDonated = donations.Where(d => d.EstimatedValue.HasValue).Sum(d => d.EstimatedValue!.Value)
            };

            var donationList = new DonationListViewModel
            {
                Donations = recentDonations,
                TotalCount = donations.Count,
                TotalValue = donations.Where(d => d.EstimatedValue.HasValue).Sum(d => d.EstimatedValue!.Value),
                PendingCount = donations.Count(d => d.Status == DonationStatus.Pending),
                ApprovedCount = donations.Count(d => d.Status == DonationStatus.Approved),
                DeliveredCount = donations.Count(d => d.Status == DonationStatus.Delivered)
            };

            var organizations = await _context.Organizations
                .Where(o => o.IsActive && o.IsVerified)
                .OrderBy(o => o.Name)
                .Take(5)
                .ToListAsync();

            var dashboardViewModel = new DashboardViewModel
            {
                UserProfile = userProfile,
                RecentDonations = donationList,
                Organizations = organizations,
                DonationTypeStats = donationTypeStats,
                MonthlyDonations = monthlyDonations
            };

            return View(dashboardViewModel);
        }

        // GET: Dashboard/Profile
        public async Task<IActionResult> Profile()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = await _userManager.FindByIdAsync(userId!);

            if (user == null)
            {
                return NotFound();
            }

            var donations = await _context.Donations
                .Where(d => d.UserId == userId)
                .ToListAsync();

            var viewModel = new UserProfileViewModel
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email!,
                PhoneNumber = user.PhoneNumber,
                Address = user.Address,
                City = user.City,
                State = user.State,
                ZipCode = user.ZipCode,
                DateJoined = user.DateJoined,
                TotalDonations = donations.Count,
                TotalValueDonated = donations.Where(d => d.EstimatedValue.HasValue).Sum(d => d.EstimatedValue!.Value)
            };

            return View(viewModel);
        }

        // POST: Dashboard/Profile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(UserProfileViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var user = await _userManager.FindByIdAsync(userId!);

                if (user == null)
                {
                    return NotFound();
                }

                // Update user properties
                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.PhoneNumber = model.PhoneNumber;
                user.Address = model.Address;
                user.City = model.City;
                user.State = model.State;
                user.ZipCode = model.ZipCode;

                var result = await _userManager.UpdateAsync(user);

                if (result.Succeeded)
                {
                    _logger.LogInformation("User {UserId} updated their profile", userId);
                    TempData["SuccessMessage"] = "Your profile has been updated successfully.";
                    return RedirectToAction(nameof(Profile));
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }

            return View(model);
        }
    }
}
