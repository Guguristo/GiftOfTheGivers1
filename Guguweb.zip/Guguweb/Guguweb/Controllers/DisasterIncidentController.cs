using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Guguweb.Models;
using Guguweb.Models.ViewModels;
using System.Security.Claims;

namespace Guguweb.Controllers
{
    [Authorize]
    public class DisasterIncidentController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<DisasterIncidentController> _logger;

        public DisasterIncidentController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            ILogger<DisasterIncidentController> logger)
        {
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }

        // GET: DisasterIncident
        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var incidents = await _context.DisasterIncidents
                .Include(di => di.Reporter)
                .Where(di => di.ReporterId == userId)
                .OrderByDescending(di => di.IncidentDate)
                .ToListAsync();

            var incidentViewModels = incidents.Select(di => new DisasterIncidentViewModel
            {
                Id = di.Id,
                Title = di.Title,
                DisasterType = (int)di.DisasterType,
                Severity = (int)di.Severity,
                Description = di.Description,
                Location = di.Location,
                City = di.City,
                State = di.State,
                ZipCode = di.ZipCode,
                IncidentDate = di.IncidentDate,
                AffectedArea = di.AffectedArea,
                AdditionalInfo = di.AdditionalInfo,
                Status = (int)di.Status,
                ReporterName = $"{di.Reporter.FirstName} {di.Reporter.LastName}",
                ReportDate = di.ReportDate,
                DateCreated = di.DateCreated
            }).ToList();

            var viewModel = new DisasterIncidentListViewModel
            {
                Incidents = incidentViewModels,
                TotalCount = incidentViewModels.Count,
                CriticalCount = incidentViewModels.Count(di => di.Severity == 4),
                HighCount = incidentViewModels.Count(di => di.Severity == 3),
                MediumCount = incidentViewModels.Count(di => di.Severity == 2),
                LowCount = incidentViewModels.Count(di => di.Severity == 1),
                ResolvedCount = incidentViewModels.Count(di => di.Status == 4)
            };

            return View(viewModel);
        }

        // GET: DisasterIncident/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var incident = await _context.DisasterIncidents
                .Include(di => di.Reporter)
                .FirstOrDefaultAsync(di => di.Id == id && di.ReporterId == userId);

            if (incident == null)
            {
                return NotFound();
            }

            var viewModel = new DisasterIncidentViewModel
            {
                Id = incident.Id,
                Title = incident.Title,
                DisasterType = (int)incident.DisasterType,
                Severity = (int)incident.Severity,
                Description = incident.Description,
                Location = incident.Location,
                City = incident.City,
                State = incident.State,
                ZipCode = incident.ZipCode,
                IncidentDate = incident.IncidentDate,
                AffectedArea = incident.AffectedArea,
                AdditionalInfo = incident.AdditionalInfo,
                Status = (int)incident.Status,
                ReporterName = $"{incident.Reporter.FirstName} {incident.Reporter.LastName}",
                ReportDate = incident.ReportDate,
                DateCreated = incident.DateCreated
            };

            return View(viewModel);
        }

        // GET: DisasterIncident/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DisasterIncident/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DisasterIncidentViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                
                var incident = new DisasterIncident
                {
                    ReporterId = userId!,
                    Title = model.Title,
                    DisasterType = (DisasterType)model.DisasterType,
                    Severity = (IncidentSeverity)model.Severity,
                    Description = model.Description,
                    Location = model.Location,
                    City = model.City,
                    State = model.State,
                    ZipCode = model.ZipCode,
                    IncidentDate = model.IncidentDate,
                    AffectedArea = model.AffectedArea,
                    AdditionalInfo = model.AdditionalInfo,
                    Status = IncidentStatus.Reported
                };

                _context.Add(incident);
                await _context.SaveChangesAsync();
                _logger.LogInformation("User {UserId} reported a disaster incident: {IncidentId}", userId, incident.Id);
                
                TempData["SuccessMessage"] = "Disaster incident reported successfully! Emergency responders have been notified.";
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        // GET: DisasterIncident/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var incident = await _context.DisasterIncidents
                .FirstOrDefaultAsync(di => di.Id == id && di.ReporterId == userId);

            if (incident == null)
            {
                return NotFound();
            }

            var viewModel = new DisasterIncidentViewModel
            {
                Id = incident.Id,
                Title = incident.Title,
                DisasterType = (int)incident.DisasterType,
                Severity = (int)incident.Severity,
                Description = incident.Description,
                Location = incident.Location,
                City = incident.City,
                State = incident.State,
                ZipCode = incident.ZipCode,
                IncidentDate = incident.IncidentDate,
                AffectedArea = incident.AffectedArea,
                AdditionalInfo = incident.AdditionalInfo,
                Status = (int)incident.Status
            };

            return View(viewModel);
        }

        // POST: DisasterIncident/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, DisasterIncidentViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var incident = await _context.DisasterIncidents
                .FirstOrDefaultAsync(di => di.Id == id && di.ReporterId == userId);

            if (incident == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    incident.Title = model.Title;
                    incident.DisasterType = (DisasterType)model.DisasterType;
                    incident.Severity = (IncidentSeverity)model.Severity;
                    incident.Description = model.Description;
                    incident.Location = model.Location;
                    incident.City = model.City;
                    incident.State = model.State;
                    incident.ZipCode = model.ZipCode;
                    incident.IncidentDate = model.IncidentDate;
                    incident.AffectedArea = model.AffectedArea;
                    incident.AdditionalInfo = model.AdditionalInfo;
                    incident.DateUpdated = DateTime.UtcNow;

                    _context.Update(incident);
                    await _context.SaveChangesAsync();
                    _logger.LogInformation("User {UserId} updated disaster incident: {IncidentId}", userId, incident.Id);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DisasterIncidentExists(incident.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        // GET: DisasterIncident/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var incident = await _context.DisasterIncidents
                .Include(di => di.Reporter)
                .FirstOrDefaultAsync(di => di.Id == id && di.ReporterId == userId);

            if (incident == null)
            {
                return NotFound();
            }

            var viewModel = new DisasterIncidentViewModel
            {
                Id = incident.Id,
                Title = incident.Title,
                DisasterType = (int)incident.DisasterType,
                Severity = (int)incident.Severity,
                Description = incident.Description,
                Location = incident.Location,
                City = incident.City,
                State = incident.State,
                ZipCode = incident.ZipCode,
                IncidentDate = incident.IncidentDate,
                AffectedArea = incident.AffectedArea,
                AdditionalInfo = incident.AdditionalInfo,
                Status = (int)incident.Status,
                ReporterName = $"{incident.Reporter.FirstName} {incident.Reporter.LastName}",
                ReportDate = incident.ReportDate,
                DateCreated = incident.DateCreated
            };

            return View(viewModel);
        }

        // POST: DisasterIncident/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var incident = await _context.DisasterIncidents
                .FirstOrDefaultAsync(di => di.Id == id && di.ReporterId == userId);

            if (incident != null)
            {
                _context.DisasterIncidents.Remove(incident);
                await _context.SaveChangesAsync();
                _logger.LogInformation("User {UserId} deleted disaster incident: {IncidentId}", userId, incident.Id);
            }

            return RedirectToAction(nameof(Index));
        }

        private bool DisasterIncidentExists(int id)
        {
            return _context.DisasterIncidents.Any(e => e.Id == id);
        }
    }
}
