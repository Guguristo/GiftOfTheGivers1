using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Guguweb.Models;
using Guguweb.Models.ViewModels;
using System.Security.Claims;

namespace Guguweb.Controllers
{
    [Authorize]
    public class DonationController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<DonationController> _logger;

        public DonationController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            ILogger<DonationController> logger)
        {
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }

        // GET: Donation
        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var donations = await _context.Donations
                .Include(d => d.Organization)
                .Where(d => d.UserId == userId)
                .OrderByDescending(d => d.DateDonated)
                .ToListAsync();

            var donationViewModels = donations.Select(d => new DonationViewModel
            {
                Id = d.Id,
                Type = (int)d.Type,
                Item = d.Item,
                Quantity = d.Quantity,
                EstimatedValue = d.EstimatedValue,
                Notes = d.Notes,
                DateDonated = d.DateDonated,
                OrganizationId = d.OrganizationId,
                OrganizationName = d.Organization?.Name,
                DeliveryAddress = d.DeliveryAddress,
                DeliveryInstructions = d.DeliveryInstructions,
                DeliveryDate = d.DeliveryDate,
                Status = (int)d.Status
            }).ToList();

            var viewModel = new DonationListViewModel
            {
                Donations = donationViewModels,
                TotalCount = donationViewModels.Count,
                TotalValue = donationViewModels.Where(d => d.EstimatedValue.HasValue).Sum(d => d.EstimatedValue.Value),
                PendingCount = donationViewModels.Count(d => d.Status == 1),
                ApprovedCount = donationViewModels.Count(d => d.Status == 2),
                DeliveredCount = donationViewModels.Count(d => d.Status == 3)
            };

            return View(viewModel);
        }

        // GET: Donation/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var donation = await _context.Donations
                .Include(d => d.Organization)
                .Include(d => d.User)
                .FirstOrDefaultAsync(d => d.Id == id && d.UserId == userId);

            if (donation == null)
            {
                return NotFound();
            }

            var viewModel = new DonationViewModel
            {
                Id = donation.Id,
                Type = (int)donation.Type,
                Item = donation.Item,
                Quantity = donation.Quantity,
                EstimatedValue = donation.EstimatedValue,
                Notes = donation.Notes,
                DateDonated = donation.DateDonated,
                OrganizationId = donation.OrganizationId,
                OrganizationName = donation.Organization?.Name,
                DeliveryAddress = donation.DeliveryAddress,
                DeliveryInstructions = donation.DeliveryInstructions,
                DeliveryDate = donation.DeliveryDate,
                Status = (int)donation.Status
            };

            return View(viewModel);
        }

        // GET: Donation/Create
        public async Task<IActionResult> Create()
        {
            var organizations = await _context.Organizations
                .Where(o => o.IsActive && o.IsVerified)
                .OrderBy(o => o.Name)
                .ToListAsync();

            ViewBag.Organizations = organizations;
            return View();
        }

        // POST: Donation/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DonationViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                
                var donation = new Donation
                {
                    UserId = userId!,
                    OrganizationId = model.OrganizationId,
                    Type = (DonationType)model.Type,
                    Item = model.Item,
                    Quantity = model.Quantity,
                    EstimatedValue = model.EstimatedValue,
                    Notes = model.Notes,
                    DateDonated = model.DateDonated,
                    DeliveryAddress = model.DeliveryAddress,
                    DeliveryInstructions = model.DeliveryInstructions,
                    DeliveryDate = model.DeliveryDate,
                    Status = DonationStatus.Pending
                };

                _context.Add(donation);
                await _context.SaveChangesAsync();
                _logger.LogInformation("User {UserId} created a new donation: {DonationId}", userId, donation.Id);
                
                return RedirectToAction(nameof(Index));
            }

            var organizations = await _context.Organizations
                .Where(o => o.IsActive && o.IsVerified)
                .OrderBy(o => o.Name)
                .ToListAsync();

            ViewBag.Organizations = organizations;
            return View(model);
        }

        // GET: Donation/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var donation = await _context.Donations
                .FirstOrDefaultAsync(d => d.Id == id && d.UserId == userId);

            if (donation == null)
            {
                return NotFound();
            }

            var viewModel = new DonationViewModel
            {
                Id = donation.Id,
                Type = (int)donation.Type,
                Item = donation.Item,
                Quantity = donation.Quantity,
                EstimatedValue = donation.EstimatedValue,
                Notes = donation.Notes,
                DateDonated = donation.DateDonated,
                OrganizationId = donation.OrganizationId,
                DeliveryAddress = donation.DeliveryAddress,
                DeliveryInstructions = donation.DeliveryInstructions,
                DeliveryDate = donation.DeliveryDate,
                Status = (int)donation.Status
            };

            var organizations = await _context.Organizations
                .Where(o => o.IsActive && o.IsVerified)
                .OrderBy(o => o.Name)
                .ToListAsync();

            ViewBag.Organizations = organizations;
            return View(viewModel);
        }

        // POST: Donation/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, DonationViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var donation = await _context.Donations
                .FirstOrDefaultAsync(d => d.Id == id && d.UserId == userId);

            if (donation == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    donation.OrganizationId = model.OrganizationId;
                    donation.Type = (DonationType)model.Type;
                    donation.Item = model.Item;
                    donation.Quantity = model.Quantity;
                    donation.EstimatedValue = model.EstimatedValue;
                    donation.Notes = model.Notes;
                    donation.DateDonated = model.DateDonated;
                    donation.DeliveryAddress = model.DeliveryAddress;
                    donation.DeliveryInstructions = model.DeliveryInstructions;
                    donation.DeliveryDate = model.DeliveryDate;
                    donation.DateUpdated = DateTime.UtcNow;

                    _context.Update(donation);
                    await _context.SaveChangesAsync();
                    _logger.LogInformation("User {UserId} updated donation: {DonationId}", userId, donation.Id);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DonationExists(donation.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            var organizations = await _context.Organizations
                .Where(o => o.IsActive && o.IsVerified)
                .OrderBy(o => o.Name)
                .ToListAsync();

            ViewBag.Organizations = organizations;
            return View(model);
        }

        // GET: Donation/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var donation = await _context.Donations
                .Include(d => d.Organization)
                .FirstOrDefaultAsync(d => d.Id == id && d.UserId == userId);

            if (donation == null)
            {
                return NotFound();
            }

            var viewModel = new DonationViewModel
            {
                Id = donation.Id,
                Type = (int)donation.Type,
                Item = donation.Item,
                Quantity = donation.Quantity,
                EstimatedValue = donation.EstimatedValue,
                Notes = donation.Notes,
                DateDonated = donation.DateDonated,
                OrganizationId = donation.OrganizationId,
                OrganizationName = donation.Organization?.Name,
                DeliveryAddress = donation.DeliveryAddress,
                DeliveryInstructions = donation.DeliveryInstructions,
                DeliveryDate = donation.DeliveryDate,
                Status = (int)donation.Status
            };

            return View(viewModel);
        }

        // POST: Donation/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var donation = await _context.Donations
                .FirstOrDefaultAsync(d => d.Id == id && d.UserId == userId);

            if (donation != null)
            {
                _context.Donations.Remove(donation);
                await _context.SaveChangesAsync();
                _logger.LogInformation("User {UserId} deleted donation: {DonationId}", userId, donation.Id);
            }

            return RedirectToAction(nameof(Index));
        }

        private bool DonationExists(int id)
        {
            return _context.Donations.Any(e => e.Id == id);
        }
    }
}
