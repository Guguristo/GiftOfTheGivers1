using System.ComponentModel.DataAnnotations;

namespace Guguweb.Models.ViewModels
{
    public class DonationViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please select a donation type")]
        [Display(Name = "Donation Type")]
        public int Type { get; set; }

        [Required(ErrorMessage = "Please specify the item being donated")]
        [StringLength(200, ErrorMessage = "Item description cannot exceed 200 characters")]
        [Display(Name = "Item Description")]
        public string Item { get; set; } = string.Empty;

        [StringLength(100, ErrorMessage = "Quantity cannot exceed 100 characters")]
        [Display(Name = "Quantity/Amount")]
        public string? Quantity { get; set; }

        [Range(0.01, double.MaxValue, ErrorMessage = "Estimated value must be greater than 0")]
        [Display(Name = "Estimated Value ($)")]
        public decimal? EstimatedValue { get; set; }

        [StringLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters")]
        [Display(Name = "Additional Notes")]
        public string? Notes { get; set; }

        [Display(Name = "Date Donated")]
        [DataType(DataType.Date)]
        public DateTime DateDonated { get; set; } = DateTime.Today;

        [Display(Name = "Organization")]
        public int? OrganizationId { get; set; }

        [StringLength(500, ErrorMessage = "Delivery address cannot exceed 500 characters")]
        [Display(Name = "Delivery Address")]
        public string? DeliveryAddress { get; set; }

        [StringLength(200, ErrorMessage = "Delivery instructions cannot exceed 200 characters")]
        [Display(Name = "Delivery Instructions")]
        public string? DeliveryInstructions { get; set; }

        [Display(Name = "Delivery Date")]
        [DataType(DataType.Date)]
        public DateTime? DeliveryDate { get; set; }

        // For display purposes
        public string TypeName => ((DonationType)Type).ToString();
        public string? OrganizationName { get; set; }
        public int Status { get; set; }
        public string StatusName => ((DonationStatus)Status).ToString();
    }

    public class DonationListViewModel
    {
        public IEnumerable<DonationViewModel> Donations { get; set; } = new List<DonationViewModel>();
        public int TotalCount { get; set; }
        public decimal TotalValue { get; set; }
        public int PendingCount { get; set; }
        public int ApprovedCount { get; set; }
        public int DeliveredCount { get; set; }
    }
}
