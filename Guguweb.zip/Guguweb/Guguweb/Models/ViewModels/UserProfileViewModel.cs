using System.ComponentModel.DataAnnotations;

namespace Guguweb.Models.ViewModels
{
    public class UserProfileViewModel
    {
        public string Id { get; set; } = string.Empty;

        [Required(ErrorMessage = "First name is required")]
        [StringLength(100, ErrorMessage = "First name cannot exceed 100 characters")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Last name is required")]
        [StringLength(100, ErrorMessage = "Last name cannot exceed 100 characters")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Phone(ErrorMessage = "Please enter a valid phone number")]
        [Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }

        [StringLength(500, ErrorMessage = "Address cannot exceed 500 characters")]
        [Display(Name = "Address")]
        public string? Address { get; set; }

        [StringLength(100, ErrorMessage = "City cannot exceed 100 characters")]
        [Display(Name = "City")]
        public string? City { get; set; }

        [StringLength(50, ErrorMessage = "State cannot exceed 50 characters")]
        [Display(Name = "State")]
        public string? State { get; set; }

        [StringLength(20, ErrorMessage = "Zip code cannot exceed 20 characters")]
        [Display(Name = "Zip Code")]
        public string? ZipCode { get; set; }

        [Display(Name = "Date Joined")]
        public DateTime DateJoined { get; set; }

        [Display(Name = "Total Donations")]
        public int TotalDonations { get; set; }

        [Display(Name = "Total Value Donated")]
        public decimal TotalValueDonated { get; set; }
    }

    public class DashboardViewModel
    {
        public UserProfileViewModel UserProfile { get; set; } = new UserProfileViewModel();
        public DonationListViewModel RecentDonations { get; set; } = new DonationListViewModel();
        public IEnumerable<Organization> Organizations { get; set; } = new List<Organization>();
        public Dictionary<string, int> DonationTypeStats { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, decimal> MonthlyDonations { get; set; } = new Dictionary<string, decimal>();
    }
}
