using System.ComponentModel.DataAnnotations;

namespace Guguweb.Models.ViewModels
{
    public class DisasterIncidentViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide a title for the incident")]
        [StringLength(200, ErrorMessage = "Title cannot exceed 200 characters")]
        [Display(Name = "Incident Title")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a disaster type")]
        [Display(Name = "Disaster Type")]
        public int DisasterType { get; set; }

        [Required(ErrorMessage = "Please select the severity level")]
        [Display(Name = "Severity Level")]
        public int Severity { get; set; }

        [Required(ErrorMessage = "Please provide a description of the incident")]
        [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters")]
        [Display(Name = "Description")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please provide the incident location")]
        [StringLength(500, ErrorMessage = "Location cannot exceed 500 characters")]
        [Display(Name = "Location")]
        public string Location { get; set; } = string.Empty;

        [StringLength(100, ErrorMessage = "City cannot exceed 100 characters")]
        [Display(Name = "City")]
        public string? City { get; set; }

        [StringLength(50, ErrorMessage = "State cannot exceed 50 characters")]
        [Display(Name = "State")]
        public string? State { get; set; }

        [StringLength(20, ErrorMessage = "Zip code cannot exceed 20 characters")]
        [Display(Name = "Zip Code")]
        public string? ZipCode { get; set; }

        [Display(Name = "Incident Date")]
        [DataType(DataType.DateTime)]
        public DateTime IncidentDate { get; set; } = DateTime.Now;

        [StringLength(500, ErrorMessage = "Affected area cannot exceed 500 characters")]
        [Display(Name = "Affected Area")]
        public string? AffectedArea { get; set; }

        [StringLength(1000, ErrorMessage = "Additional information cannot exceed 1000 characters")]
        [Display(Name = "Additional Information")]
        public string? AdditionalInfo { get; set; }

        // For display purposes
        public string DisasterTypeName => ((DisasterType)DisasterType).ToString();
        public string SeverityName => ((IncidentSeverity)Severity).ToString();
        public int Status { get; set; }
        public string StatusName => ((IncidentStatus)Status).ToString();
        public string? ReporterName { get; set; }
        public DateTime ReportDate { get; set; }
        public DateTime DateCreated { get; set; }
    }

    public class DisasterIncidentListViewModel
    {
        public IEnumerable<DisasterIncidentViewModel> Incidents { get; set; } = new List<DisasterIncidentViewModel>();
        public int TotalCount { get; set; }
        public int CriticalCount { get; set; }
        public int HighCount { get; set; }
        public int MediumCount { get; set; }
        public int LowCount { get; set; }
        public int ResolvedCount { get; set; }
    }
}
