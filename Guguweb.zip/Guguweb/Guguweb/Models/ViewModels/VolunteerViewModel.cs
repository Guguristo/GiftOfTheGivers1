using System.ComponentModel.DataAnnotations;

namespace Guguweb.Models.ViewModels
{
    public class VolunteerViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Skills are required")]
        [StringLength(500, ErrorMessage = "Skills description cannot exceed 500 characters")]
        [Display(Name = "Skills")]
        public string? Skills { get; set; }

        [StringLength(1000, ErrorMessage = "Experience description cannot exceed 1000 characters")]
        [Display(Name = "Experience")]
        public string? Experience { get; set; }

        [StringLength(500, ErrorMessage = "Availability cannot exceed 500 characters")]
        [Display(Name = "Availability")]
        public string? Availability { get; set; }

        [StringLength(200, ErrorMessage = "Emergency contact name cannot exceed 200 characters")]
        [Display(Name = "Emergency Contact Name")]
        public string? EmergencyContact { get; set; }

        [StringLength(20, ErrorMessage = "Emergency phone cannot exceed 20 characters")]
        [Display(Name = "Emergency Contact Phone")]
        public string? EmergencyPhone { get; set; }

        [Required(ErrorMessage = "Please select your skill level")]
        [Display(Name = "Skill Level")]
        public int SkillLevel { get; set; }

        // For display purposes
        public string SkillLevelName => ((SkillLevel)SkillLevel).ToString();
        public int Status { get; set; }
        public string StatusName => ((VolunteerStatus)Status).ToString();
        public string? UserName { get; set; }
        public string? UserEmail { get; set; }
        public DateTime DateJoined { get; set; }
        public int TotalTasks { get; set; }
        public int CompletedTasks { get; set; }
        public int TotalHours { get; set; }
    }

    public class VolunteerTaskViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide a title for the task")]
        [StringLength(200, ErrorMessage = "Title cannot exceed 200 characters")]
        [Display(Name = "Task Title")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a task type")]
        [Display(Name = "Task Type")]
        public int Type { get; set; }

        [Required(ErrorMessage = "Please select the priority level")]
        [Display(Name = "Priority")]
        public int Priority { get; set; }

        [Required(ErrorMessage = "Please provide a description of the task")]
        [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters")]
        [Display(Name = "Description")]
        public string Description { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "Location cannot exceed 500 characters")]
        [Display(Name = "Location")]
        public string? Location { get; set; }

        [Display(Name = "Start Date")]
        [DataType(DataType.DateTime)]
        public DateTime? StartDate { get; set; }

        [Display(Name = "End Date")]
        [DataType(DataType.DateTime)]
        public DateTime? EndDate { get; set; }

        [Range(1, 100, ErrorMessage = "Required volunteers must be between 1 and 100")]
        [Display(Name = "Required Volunteers")]
        public int? RequiredVolunteers { get; set; }

        [StringLength(500, ErrorMessage = "Required skills cannot exceed 500 characters")]
        [Display(Name = "Required Skills")]
        public string? RequiredSkills { get; set; }

        [StringLength(1000, ErrorMessage = "Instructions cannot exceed 1000 characters")]
        [Display(Name = "Instructions")]
        public string? Instructions { get; set; }

        [StringLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters")]
        [Display(Name = "Notes")]
        public string? Notes { get; set; }

        // For display purposes
        public string TypeName => ((TaskType)Type).ToString();
        public string PriorityName => ((TaskPriority)Priority).ToString();
        public int Status { get; set; }
        public string StatusName => ((TaskStatus)Status).ToString();
        public DateTime DateCreated { get; set; }
        public int AssignedVolunteers { get; set; }
        public int CompletedVolunteers { get; set; }
    }

    public class VolunteerTaskAssignmentViewModel
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public int VolunteerId { get; set; }
        public int Status { get; set; }
        public string StatusName => ((AssignmentStatus)Status).ToString();
        public DateTime AssignedDate { get; set; }
        public DateTime? AcceptedDate { get; set; }
        public DateTime? StartedDate { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string? VolunteerNotes { get; set; }
        public string? SupervisorNotes { get; set; }
        public int? HoursWorked { get; set; }

        // Navigation properties for display
        public string? TaskTitle { get; set; }
        public string? VolunteerName { get; set; }
        public string? TaskType { get; set; }
        public string? TaskPriority { get; set; }
    }
}
