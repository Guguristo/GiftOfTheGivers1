using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Guguweb.Models
{
    public enum VolunteerStatus
    {
        Active = 1,
        Inactive = 2,
        Suspended = 3
    }

    public enum SkillLevel
    {
        Beginner = 1,
        Intermediate = 2,
        Advanced = 3,
        Expert = 4
    }

    public class Volunteer
    {
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Skills { get; set; }

        [MaxLength(1000)]
        public string? Experience { get; set; }

        [MaxLength(500)]
        public string? Availability { get; set; }

        [MaxLength(200)]
        public string? EmergencyContact { get; set; }

        [MaxLength(20)]
        public string? EmergencyPhone { get; set; }

        public VolunteerStatus Status { get; set; } = VolunteerStatus.Active;

        public SkillLevel SkillLevel { get; set; } = SkillLevel.Beginner;

        public DateTime DateJoined { get; set; } = DateTime.UtcNow;

        public DateTime? DateUpdated { get; set; }

        // Navigation properties
        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; } = null!;

        public virtual ICollection<VolunteerTask> AssignedTasks { get; set; } = new List<VolunteerTask>();
    }
}
