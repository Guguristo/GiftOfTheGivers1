using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Guguweb.Models
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Organization> Organizations { get; set; }
        public DbSet<Donation> Donations { get; set; }
        public DbSet<DisasterIncident> DisasterIncidents { get; set; }
        public DbSet<Volunteer> Volunteers { get; set; }
        public DbSet<VolunteerTask> VolunteerTasks { get; set; }
        public DbSet<VolunteerTaskAssignment> VolunteerTaskAssignments { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure Donation entity
            builder.Entity<Donation>()
                .HasOne(d => d.User)
                .WithMany(u => u.Donations)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<Donation>()
                .HasOne(d => d.Organization)
                .WithMany(o => o.Donations)
                .HasForeignKey(d => d.OrganizationId)
                .OnDelete(DeleteBehavior.SetNull);

            // Configure DisasterIncident entity
            builder.Entity<DisasterIncident>()
                .HasOne(di => di.Reporter)
                .WithMany()
                .HasForeignKey(di => di.ReporterId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure Volunteer entity
            builder.Entity<Volunteer>()
                .HasOne(v => v.User)
                .WithMany()
                .HasForeignKey(v => v.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure VolunteerTaskAssignment entity
            builder.Entity<VolunteerTaskAssignment>()
                .HasOne(vta => vta.Task)
                .WithMany(vt => vt.Assignments)
                .HasForeignKey(vta => vta.TaskId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<VolunteerTaskAssignment>()
                .HasOne(vta => vta.Volunteer)
                .WithMany()
                .HasForeignKey(vta => vta.VolunteerId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure ApplicationUser entity
            builder.Entity<ApplicationUser>()
                .Property(u => u.FirstName)
                .IsRequired()
                .HasMaxLength(100);

            builder.Entity<ApplicationUser>()
                .Property(u => u.LastName)
                .IsRequired()
                .HasMaxLength(100);

            // Configure Organization entity
            builder.Entity<Organization>()
                .Property(o => o.Name)
                .IsRequired()
                .HasMaxLength(200);

            // Seed data
            SeedData(builder);
        }

        private void SeedData(ModelBuilder builder)
        {
            // Seed organizations
            builder.Entity<Organization>().HasData(
                new Organization
                {
                    Id = 1,
                    Name = "Local Food Bank",
                    Description = "Providing food assistance to families in need",
                    ContactPerson = "John Smith",
                    Email = "contact@localfoodbank.org",
                    Phone = "555-1234",
                    Address = "123 Main St",
                    City = "Anytown",
                    State = "CA",
                    ZipCode = "12345",
                    IsVerified = true,
                    DateCreated = DateTime.UtcNow
                },
                new Organization
                {
                    Id = 2,
                    Name = "Community Clothing Drive",
                    Description = "Collecting and distributing clothing to those in need",
                    ContactPerson = "Sarah Johnson",
                    Email = "info@communityclothing.org",
                    Phone = "555-5678",
                    Address = "456 Oak Ave",
                    City = "Anytown",
                    State = "CA",
                    ZipCode = "12346",
                    IsVerified = true,
                    DateCreated = DateTime.UtcNow
                },
                new Organization
                {
                    Id = 3,
                    Name = "Emergency Relief Fund",
                    Description = "Providing financial assistance during emergencies",
                    ContactPerson = "Mike Davis",
                    Email = "relief@emergencyfund.org",
                    Phone = "555-9012",
                    Address = "789 Pine St",
                    City = "Anytown",
                    State = "CA",
                    ZipCode = "12347",
                    IsVerified = true,
                    DateCreated = DateTime.UtcNow
                }
            );
        }
    }
}
