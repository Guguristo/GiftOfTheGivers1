using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Guguweb.Models
{
    public enum DonationType
    {
        Food = 1,
        Clothing = 2,
        Cash = 3,
        Services = 4,
        Other = 5
    }

    public enum DonationStatus
    {
        Pending = 1,
        Approved = 2,
        Delivered = 3,
        Cancelled = 4
    }

    public class Donation
    {
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;

        public int? OrganizationId { get; set; }

        [Required]
        public DonationType Type { get; set; }

        [Required]
        [MaxLength(200)]
        public string Item { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? Quantity { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? EstimatedValue { get; set; }

        [MaxLength(1000)]
        public string? Notes { get; set; }

        public DateTime DateDonated { get; set; } = DateTime.UtcNow;

        public DonationStatus Status { get; set; } = DonationStatus.Pending;

        [MaxLength(500)]
        public string? DeliveryAddress { get; set; }

        [MaxLength(200)]
        public string? DeliveryInstructions { get; set; }

        public DateTime? DeliveryDate { get; set; }

        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        public DateTime? DateUpdated { get; set; }

        // Navigation properties
        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; } = null!;

        [ForeignKey("OrganizationId")]
        public virtual Organization? Organization { get; set; }
    }
}
