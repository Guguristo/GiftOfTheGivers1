using System.ComponentModel.DataAnnotations;

namespace Guguweb.Models
{
    public class Organization
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(1000)]
        public string? Description { get; set; }

        [MaxLength(200)]
        public string? ContactPerson { get; set; }

        [MaxLength(100)]
        public string? Email { get; set; }

        [MaxLength(20)]
        public string? Phone { get; set; }

        [MaxLength(500)]
        public string? Address { get; set; }

        [MaxLength(100)]
        public string? City { get; set; }

        [MaxLength(50)]
        public string? State { get; set; }

        [MaxLength(20)]
        public string? ZipCode { get; set; }

        [MaxLength(100)]
        public string? Website { get; set; }

        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        public bool IsVerified { get; set; } = false;

        public bool IsActive { get; set; } = true;

        // Navigation properties
        public virtual ICollection<Donation> Donations { get; set; } = new List<Donation>();
    }
}
