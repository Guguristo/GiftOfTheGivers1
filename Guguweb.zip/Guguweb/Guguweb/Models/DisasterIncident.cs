using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Guguweb.Models
{
    public enum DisasterType
    {
        Flood = 1,
        Fire = 2,
        Earthquake = 3,
        Hurricane = 4,
        Tornado = 5,
        Landslide = 6,
        Drought = 7,
        Storm = 8,
        Other = 9
    }

    public enum IncidentSeverity
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }

    public enum IncidentStatus
    {
        Reported = 1,
        UnderReview = 2,
        InProgress = 3,
        Resolved = 4,
        Closed = 5
    }

    public class DisasterIncident
    {
        public int Id { get; set; }

        [Required]
        public string ReporterId { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public DisasterType DisasterType { get; set; }

        [Required]
        public IncidentSeverity Severity { get; set; }

        [Required]
        [MaxLength(1000)]
        public string Description { get; set; } = string.Empty;

        [Required]
        [MaxLength(500)]
        public string Location { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? City { get; set; }

        [MaxLength(50)]
        public string? State { get; set; }

        [MaxLength(20)]
        public string? ZipCode { get; set; }

        [MaxLength(50)]
        public string? Latitude { get; set; }

        [MaxLength(50)]
        public string? Longitude { get; set; }

        public DateTime IncidentDate { get; set; } = DateTime.UtcNow;

        public DateTime ReportDate { get; set; } = DateTime.UtcNow;

        public IncidentStatus Status { get; set; } = IncidentStatus.Reported;

        [MaxLength(500)]
        public string? AffectedArea { get; set; }

        [MaxLength(1000)]
        public string? AdditionalInfo { get; set; }

        [MaxLength(1000)]
        public string? AdminNotes { get; set; }

        public DateTime? DateResolved { get; set; }

        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        public DateTime? DateUpdated { get; set; }

        // Navigation properties
        [ForeignKey("ReporterId")]
        public virtual ApplicationUser Reporter { get; set; } = null!;
    }
}
