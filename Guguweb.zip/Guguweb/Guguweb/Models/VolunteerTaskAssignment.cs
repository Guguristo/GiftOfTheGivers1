using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Guguweb.Models
{
    public enum AssignmentStatus
    {
        Assigned = 1,
        Accepted = 2,
        Started = 3,
        Completed = 4,
        Cancelled = 5,
        NoShow = 6
    }

    public class VolunteerTaskAssignment
    {
        public int Id { get; set; }

        [Required]
        public int TaskId { get; set; }

        [Required]
        public int VolunteerId { get; set; }

        public AssignmentStatus Status { get; set; } = AssignmentStatus.Assigned;

        public DateTime AssignedDate { get; set; } = DateTime.UtcNow;

        public DateTime? AcceptedDate { get; set; }

        public DateTime? StartedDate { get; set; }

        public DateTime? CompletedDate { get; set; }

        [MaxLength(1000)]
        public string? VolunteerNotes { get; set; }

        [MaxLength(1000)]
        public string? SupervisorNotes { get; set; }

        public int? HoursWorked { get; set; }

        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        public DateTime? DateUpdated { get; set; }

        // Navigation properties
        [ForeignKey("TaskId")]
        public virtual VolunteerTask Task { get; set; } = null!;

        [ForeignKey("VolunteerId")]
        public virtual Volunteer Volunteer { get; set; } = null!;
    }
}
