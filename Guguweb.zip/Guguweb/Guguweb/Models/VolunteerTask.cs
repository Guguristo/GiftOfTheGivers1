using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Guguweb.Models
{
    public enum TaskType
    {
        EmergencyResponse = 1,
        ReliefDistribution = 2,
        CommunitySupport = 3,
        Administrative = 4,
        Communication = 5,
        Transportation = 6,
        MedicalSupport = 7,
        Other = 8
    }

    public enum TaskPriority
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Urgent = 4
    }

    public enum TaskStatus
    {
        Open = 1,
        Assigned = 2,
        InProgress = 3,
        Completed = 4,
        Cancelled = 5
    }

    public class VolunteerTask
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public TaskType Type { get; set; }

        [Required]
        public TaskPriority Priority { get; set; }

        [Required]
        [MaxLength(1000)]
        public string Description { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Location { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int? RequiredVolunteers { get; set; }

        public TaskStatus Status { get; set; } = TaskStatus.Open;

        [MaxLength(500)]
        public string? RequiredSkills { get; set; }

        [MaxLength(1000)]
        public string? Instructions { get; set; }

        [MaxLength(1000)]
        public string? Notes { get; set; }

        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        public DateTime? DateUpdated { get; set; }

        // Navigation properties
        public virtual ICollection<VolunteerTaskAssignment> Assignments { get; set; } = new List<VolunteerTaskAssignment>();
    }
}
